import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Carrega variáveis de ambiente do arquivo .env
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # Se python-dotenv não estiver instalado, carrega manualmente
    env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env')
    if os.path.exists(env_path):
        with open(env_path, 'r') as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    os.environ[key] = value

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.models.user import db
from src.routes.user import user_bp
from src.routes.content import content_bp
from src.routes.download import download_bp

# Importar configuração de deployment
try:
    from deploy_config import get_config
    config = get_config()
except ImportError:
    # Fallback para configuração padrão
    class DefaultConfig:
        PORT = int(os.environ.get('PORT', 5000))
        HOST = os.environ.get('HOST', '0.0.0.0')
        DEBUG = os.environ.get('DEBUG', 'False').lower() == 'true'
    config = DefaultConfig()

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Habilita CORS para todas as rotas
CORS(app)

app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(content_bp, url_prefix='/api')
app.register_blueprint(download_bp, url_prefix='/api/download')

# uncomment if you need to use database
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)
with app.app_context():
    db.create_all()

@app.route('/health')
def health():
    """Health check endpoint para deployment"""
    return {
        "status": "healthy", 
        "timestamp": "2025-08-10T00:00:00Z",
        "version": "1.0.0"
    }

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    if path == "":
        # Página inicial com informações do sistema
        try:
            deployment_info = config.get_deployment_info()
        except:
            deployment_info = {
                'environment': 'production' if not config.DEBUG else 'development',
                'host': config.HOST,
                'port': config.PORT
            }
        
        return {
            "message": "🎬 Sistema de Automação de Vídeos com IA",
            "version": "1.0.0",
            "status": "running",
            "description": "Sistema automatizado para gerar 6 vídeos diários (1:10-2min) sobre tendências e postar no TikTok e YouTube",
            "deployment": deployment_info,
            "features": [
                "Coleta automática de tendências",
                "Geração de roteiros com IA",
                "Criação de vídeos com imagens, áudio e música",
                "Upload automático para TikTok e YouTube",
                "Agendamento nos melhores horários"
            ],
            "endpoints": {
                "health": "/health",
                "dashboard": "/api/system/dashboard",
                "config": "/api/config",
                "trends": "/api/trends",
                "generate_content": "/api/generate-daily-content",
                "generate_video": "/api/generate-video",
                "upload_video": "/api/upload-video",
                "scheduler_status": "/api/scheduler/status",
                "start_scheduler": "/api/scheduler/start",
                "stop_scheduler": "/api/scheduler/stop",
                "list_videos": "/api/download/videos",
                "download_video": "/api/download/video/<filename>",
                "storage_info": "/api/download/storage-info"
            }
        }
    
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    # Criar diretórios necessários
    try:
        config.create_directories()
    except:
        pass
    
    # Validar configuração
    try:
        errors = config.validate_config()
        if errors:
            print("⚠️ AVISOS DE CONFIGURAÇÃO:")
            for error in errors:
                print(f"  - {error}")
        else:
            print("✅ Configuração validada com sucesso")
    except:
        print("⚠️ Usando configuração padrão")
    
    # Inicializa o agendador automaticamente
    try:
        from src.services.scheduler import automation_scheduler
        automation_scheduler.start_scheduler()
        print("✅ Agendador automático iniciado")
    except Exception as e:
        print(f"❌ Erro ao iniciar agendador: {e}")
    
    # Inicia o servidor Flask
    print(f"🚀 Iniciando servidor em {config.HOST}:{config.PORT}")
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG)
