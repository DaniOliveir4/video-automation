
# Flask App (Scaffold)

Este projeto foi completado com um esqueleto operacional baseado no `main.py` fornecido.

## Como rodar localmente

1. Crie um virtualenv e instale dependências:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. Copie `.env.example` para `.env` e ajuste o `SECRET_KEY` e outras configs.

3. Inicialize a base de dados (SQLite) automaticamente na primeira execução.

4. Rode o servidor:
   ```bash
   python main.py
   ```

## Endpoints
- `GET /health` — health check
- `POST /api/auth/login` — retorna token simples
- `GET /api/auth/me` — retorna usuário autenticado (enviar `Authorization: Bearer <token>`)
- `GET /api/items` — lista itens
- `POST /api/items` — cria item `{ "name": "Exemplo", "description": "..." }`
- `DELETE /api/items/<id>` — remove item
- `GET /api/download/items.csv` — baixa CSV com itens

## Scheduler
Usa APScheduler com um job de *heartbeat* a cada 1 minuto (exemplo). Para jobs reais, adicionar em `src/services/scheduler/automation_scheduler.py`.


---
## Upload para Google Drive (gratuito) via rclone

**Pré-requisitos:**
- Instale o rclone: https://rclone.org/downloads/
- Configure um remote chamado `gdrive` (ou outro nome) com `rclone config` (tipo Google Drive).

**Variáveis de ambiente:**
- `DRIVE_UPLOAD_ENABLED=true`
- `DRIVE_PROVIDER=rclone`
- `RCLONE_REMOTE=gdrive`                  # nome do remote criado
- `RCLONE_BASEDIR=Videos`                 # pasta raiz no Drive
- `VIDEO_OUTPUT_DIR=/mnt/data/output/videos`

**Endpoint para upload:**
- `POST /api/upload/google-drive` com JSON `{"filename": "video_tiktok_XXXX.mp4"}`

**Estrutura no Drive:**
- `Videos/<plataforma>/<YYYY>/<MM>/<DD>/<arquivo>.mp4`
