
import os, subprocess, shutil
from pathlib import Path
from datetime import datetime

OUTPUT_DIR = Path(os.getenv("VIDEO_OUTPUT_DIR", "/mnt/data/output/videos"))
PROVIDER = os.getenv("DRIVE_PROVIDER", "rclone").lower()
ENABLED = os.getenv("DRIVE_UPLOAD_ENABLED", "false").lower() == "true"
RCLONE_REMOTE = os.getenv("RCLONE_REMOTE", "gdrive")
RCLONE_BASEDIR = os.getenv("RCLONE_BASEDIR", "Videos")

def _target_dir(platform: str, created_at_iso: str) -> str:
    try:
        dt = datetime.fromisoformat(created_at_iso.replace("Z",""))
    except Exception:
        dt = datetime.utcnow()
    return f"{RCLONE_BASEDIR}/{platform}/{dt:%Y}/{dt:%m}/{dt:%d}"

def _rclone_copy(local_path: Path, remote_dir: str) -> tuple[bool, str]:
    if shutil.which("rclone") is None:
        return False, "rclone não encontrado no PATH. Instale e configure com 'rclone config'."
    remote = f"{RCLONE_REMOTE}:{remote_dir}"
    cmd = ["rclone", "copyto", str(local_path), f"{remote}/{local_path.name}", "-v"]
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, check=True)
        return True, out.stdout.strip()
    except subprocess.CalledProcessError as e:
        return False, (e.stdout or "") + (e.stderr or "")

def upload_file(filename: str, platform: str, created_at_iso: str) -> dict:
    if not ENABLED:
        return {"uploaded": False, "reason": "upload desabilitado (DRIVE_UPLOAD_ENABLED=false)"}
    path = OUTPUT_DIR / filename
    if not path.exists():
        return {"uploaded": False, "reason": f"arquivo não encontrado: {filename}"}
    target_dir = _target_dir(platform, created_at_iso)
    if PROVIDER == "rclone":
        ok, msg = _rclone_copy(path, target_dir)
        return {"uploaded": ok, "provider": "rclone", "remote_dir": target_dir, "message": msg}
    return {"uploaded": False, "reason": f"provider não suportado: {PROVIDER}"}
