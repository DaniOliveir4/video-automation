
import os, json, uuid, random
from pathlib import Path
from datetime import datetime

OUTPUT_DIR = Path(os.getenv("VIDEO_OUTPUT_DIR", "/mnt/data/output/videos"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

SAMPLE_TRENDS = [
    {"topic": "IA no dia a dia", "category": "Tecnologia"},
    {"topic": "Rotina de dados de BI", "category": "Negócios"},
    {"topic": "Dicas de conversão em anúncios", "category": "Marketing"},
    {"topic": "Automação com Python no trabalho", "category": "Produtividade"},
    {"topic": "Tendências do TikTok agora", "category": "Social"},
    {"topic": "Storytelling com dados", "category": "Data Story"}
]

def _fake_video_bytes(seconds: int = 2) -> bytes:
    # Apenas um placeholder binário para simular um MP4 (não reproduzível de fato)
    header = b"\x00\x00\x00 ftypisom\x00\x00\x02\x00isomiso2"
    payload = os.urandom(1024 * max(1, seconds))
    return header + payload

def _pick_trend():
    t = random.choice(SAMPLE_TRENDS)
    title = f"{t['topic']} #{random.randint(100,999)}"
    tags = [t['category'], "shorts", "viral", "tips"]
    return t['topic'], t['category'], title, tags

def generate_video(platform: str = "generic") -> dict:
    topic, category, title, tags = _pick_trend()
    uid = uuid.uuid4().hex[:10]
    filename = f"video_{platform}_{uid}.mp4"
    meta_name = f"{filename}.json"
    out_video = OUTPUT_DIR / filename
    out_meta = OUTPUT_DIR / meta_name

    # Simula geração de vídeo
    data = _fake_video_bytes()
    with open(out_video, "wb") as f:
        f.write(data)

    metadata = {
        "filename": filename,
        "title": title,
        "description": f"Video sobre {topic}. Plataforma: {platform}.",
        "tags": tags,
        "category": category,
        "duration_seconds": random.randint(70, 120),
        "resolution": "1080x1920",
        "created_at": datetime.utcnow().isoformat() + "Z",
        "platform": platform
    }
    with open(out_meta, "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)

    return metadata

def list_videos() -> list:
    items = []
    for p in OUTPUT_DIR.glob("*.mp4"):
        meta_file = OUTPUT_DIR / f"{p.name}.json"
        meta = {"filename": p.name, "size_bytes": p.stat().st_size}
        if meta_file.exists():
            try:
                import json
                meta.update(json.loads(meta_file.read_text(encoding="utf-8")))
            except Exception:
                pass
        items.append(meta)
    # ordena por data se houver
    items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return items
