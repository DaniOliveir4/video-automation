
import logging
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

_scheduler = None
logger = logging.getLogger(__name__)

def _heartbeat():
    logger.info("Scheduler heartbeat %s", datetime.utcnow().isoformat())

def _generate(platform: str, count: int):
    try:
        from ..video.generator import generate_video
        for _ in range(count):
            meta = generate_video(platform=platform)
            logger.info("Generated video: %s", meta.get("filename"))
    except Exception as e:
        logger.exception("Generation failed: %s", e)

def start_scheduler():
    global _scheduler
    if _scheduler:
        return _scheduler
    _scheduler = BackgroundScheduler(timezone="America/Sao_Paulo")
    _scheduler.add_job(_heartbeat, "interval", minutes=1, id="heartbeat", replace_existing=True)

    # === 17 Jobs conforme briefing ===
    # TikTok (3 vídeos/dia): Seg/Qua 07:00; Ter/Qui 14:00; Sex/Sáb/Dom 20:00
    _scheduler.add_job(_generate, CronTrigger(day_of_week="mon,wed", hour=7, minute=0), id="tiktok_mw_0700", args=["tiktok", 3], replace_existing=True)
    _scheduler.add_job(_generate, CronTrigger(day_of_week="tue,thu", hour=14, minute=0), id="tiktok_tt_1400", args=["tiktok", 3], replace_existing=True)
    _scheduler.add_job(_generate, CronTrigger(day_of_week="fri,sat,sun", hour=20, minute=0), id="tiktok_fss_2000", args=["tiktok", 3], replace_existing=True)

    # YouTube (3 vídeos/dia): Ter/Qua/Qui 14:00; Sex/Sáb/Dom 19:00; Sáb/Dom 09:00
    _scheduler.add_job(_generate, CronTrigger(day_of_week="tue,wed,thu", hour=14, minute=0), id="yt_twt_1400", args=["youtube", 3], replace_existing=True)
    _scheduler.add_job(_generate, CronTrigger(day_of_week="fri,sat,sun", hour=19, minute=0), id="yt_fss_1900", args=["youtube", 3], replace_existing=True)
    _scheduler.add_job(_generate, CronTrigger(day_of_week="sat,sun", hour=9, minute=0), id="yt_ss_0900", args=["youtube", 3], replace_existing=True)

    # Isso dá 3 + 3 + 3 + 3 + 3 + 2 = 17 execuções semanais (janelas). Cada job dispara nos dias/horas definidos.
    _scheduler.start()
    return _scheduler

def get_scheduler():
    return _scheduler
