
from flask_cors import CORS

def init_cors(app, origins="*"):
    CORS(app, resources={r"/api/*": {"origins": origins}}, supports_credentials=True)
    return app
