
from flask import Blueprint, jsonify, request, abort
from ..services.storage.uploader import upload_file
from ..services.video.generator import list_videos

upload_bp = Blueprint("upload", __name__)

@upload_bp.route("/upload/google-drive", methods=["POST"])
def upload_google_drive():
    data = request.get_json(silent=True) or {}
    filename = data.get("filename")
    if not filename:
        abort(400, "filename é obrigatório")
    # tenta descobrir plataforma e created_at pelos metadados
    meta = next((v for v in list_videos() if v.get("filename")==filename), None)
    if not meta:
        abort(404, "vídeo não encontrado")
    res = upload_file(filename=filename, platform=meta.get("platform","generic"), created_at_iso=meta.get("created_at",""))
    return jsonify(res), (200 if res.get("uploaded") else 400)
