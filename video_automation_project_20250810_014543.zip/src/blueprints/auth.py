
from flask import Blueprint, request, jsonify, current_app
from itsdangerous import URLSafeSerializer

auth_bp = Blueprint("auth", __name__)

def _sign(payload: dict) -> str:
    s = URLSafeSerializer(current_app.config["SECRET_KEY"], salt="auth")
    return s.dumps(payload)

def _unsign(token: str) -> dict:
    s = URLSafeSerializer(current_app.config["SECRET_KEY"], salt="auth")
    return s.loads(token)

@auth_bp.route("/auth/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    user = data.get("user") or "guest"
    token = _sign({"user": user})
    return jsonify({"access_token": token, "user": user})

@auth_bp.route("/auth/me", methods=["GET"])
def me():
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    if not token:
        return jsonify({"error": "missing token"}), 401
    try:
        payload = _unsign(token)
        return jsonify({"user": payload.get("user")})
    except Exception:
        return jsonify({"error": "invalid token"}), 401
