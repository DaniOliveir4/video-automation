
import io, csv, os
from pathlib import Path
from flask import Blueprint, send_file, jsonify, abort
from ..models import Item

download_bp = Blueprint("download", __name__)

@download_bp.route("/download/items.csv", methods=["GET"])
def download_items_csv():
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["id", "name", "description", "created_at"])
    for item in Item.query.order_by(Item.id.asc()).all():
        writer.writerow([item.id, item.name, item.description or "", item.created_at.isoformat()])
    mem = io.BytesIO(buf.getvalue().encode("utf-8"))
    mem.seek(0)
    return send_file(mem, mimetype="text/csv", as_attachment=True, download_name="items.csv")

# ===== New: video listing & download =====
OUTPUT_DIR = Path(os.getenv("VIDEO_OUTPUT_DIR", "/mnt/data/output/videos"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

@download_bp.route("/download/videos", methods=["GET"])
def list_videos():
    files = []
    for p in sorted(OUTPUT_DIR.glob("*.mp4")):
        meta = {}
        meta_path = OUTPUT_DIR / f"{p.name}.json"
        if meta_path.exists():
            try:
                import json
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        files.append({
            "filename": p.name,
            "size_bytes": p.stat().st_size,
            **meta
        })
    files.sort(key=lambda x: x.get("created_at",""), reverse=True)
    return jsonify(files)

@download_bp.route("/download/video/<path:filename>", methods=["GET"])
def download_video(filename):
    safe = Path(filename).name
    path = OUTPUT_DIR / safe
    if not path.exists():
        abort(404, f"Arquivo não encontrado: {safe}")
    return send_file(path, mimetype="video/mp4", as_attachment=True, download_name=safe)
