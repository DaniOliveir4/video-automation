
from flask import Blueprint, jsonify, request
from ..extensions.db import db
from ..models import Item

content_bp = Blueprint("content", __name__)

@content_bp.route("/items", methods=["GET"])
def list_items():
    items = Item.query.order_by(Item.id.desc()).all()
    return jsonify([i.as_dict() for i in items])

@content_bp.route("/items", methods=["POST"])
def create_item():
    data = request.get_json(silent=True) or {}
    name = data.get("name")
    description = data.get("description", "")
    if not name:
        return {"error": "name is required"}, 400
    item = Item(name=name, description=description)
    db.session.add(item)
    db.session.commit()
    return item.as_dict(), 201

@content_bp.route("/items/<int:item_id>", methods=["GET"])
def get_item(item_id):
    item = Item.query.get_or_404(item_id)
    return item.as_dict()

@content_bp.route("/items/<int:item_id>", methods=["DELETE"])
def delete_item(item_id):
    item = Item.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    return {"ok": True}
