
from flask import Blueprint, jsonify, request
from ..services.video.generator import generate_video

generate_bp = Blueprint("generate", __name__)

@generate_bp.route("/generate-daily-content", methods=["POST","GET"])
def generate_daily_content():
    # Permite sobrescrever qtd via query (?count=3&platform=tiktok)
    try:
        count = int(request.args.get("count", request.json.get("count") if request.is_json else 6))
    except Exception:
        count = 6
    platform = request.args.get("platform", (request.json.get("platform") if request.is_json else "generic"))
    results = [generate_video(platform=platform) for _ in range(max(1, count))]
    return jsonify({"generated": results, "count": len(results)}), 201
