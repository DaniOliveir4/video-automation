
from flask import Blueprint, jsonify
from apscheduler.schedulers.base import STATE_RUNNING
from ..services.video.generator import list_videos
from ..services.scheduler.automation_scheduler import get_scheduler

system_bp = Blueprint("system", __name__)

@system_bp.route("/system/dashboard", methods=["GET"])
def dashboard():
    sched = get_scheduler()
    status = "running" if (sched and sched.state == STATE_RUNNING) else "stopped"
    jobs = [{
        "id": j.id,
        "next_run_time": j.next_run_time.isoformat() if j.next_run_time else None,
        "trigger": str(j.trigger)
    } for j in (sched.get_jobs() if sched else [])]
    videos = list_videos()
    return jsonify({
        "scheduler": {"status": status, "jobs": jobs, "count": len(jobs)},
        "stats": {
            "videos_total": len(videos),
            "videos_today": sum(1 for v in videos if str(v.get("created_at",""))[:10] == __import__("datetime").datetime.utcnow().date().isoformat())
        },
        "videos_sample": videos[:10]
    })
