
#!/usr/bin/env bash
set -e

# Configure timezone if provided
if [ -n "$TZ" ]; then
  echo "Setting timezone to $TZ"
  ln -snf /usr/share/zoneinfo/$TZ /etc/localtime && echo $TZ > /etc/timezone
fi

# If RCLONE_CONF_BASE64 provided, write it
export RCLONE_CONFIG_DIR=${RCLONE_CONFIG_DIR:-/root/.config/rclone}
mkdir -p "$RCLONE_CONFIG_DIR"
if [ -n "$RCLONE_CONF_BASE64" ]; then
  echo "$RCLONE_CONF_BASE64" | base64 -d > "$RCLONE_CONFIG_DIR/rclone.conf"
  echo "rclone.conf materializado em $RCLONE_CONFIG_DIR/rclone.conf"
fi

# Ensure output dir exists
mkdir -p "${VIDEO_OUTPUT_DIR:-/app/output/videos}"

# Run app
exec python main.py
