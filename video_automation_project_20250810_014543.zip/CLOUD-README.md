
# Deploy em Nuvem (Render.com ou Railway)

## Opção A — Render.com (simples)
1. Faça fork ou envie este projeto para um repositório seu (GitHub).
2. Em https://render.com > New + > Web Service > conecte seu repositório.
3. Selecione "Deploy from Dockerfile".
4. Defina as variáveis de ambiente (veja `render.yaml` para referência):
   - `PORT=8000`
   - `HOST=0.0.0.0`
   - `TZ=America/Sao_Paulo`
   - `DRIVE_UPLOAD_ENABLED=true`
   - `DRIVE_PROVIDER=rclone`
   - `RCLONE_REMOTE=gdrive`
   - `RCLONE_BASEDIR=Videos`
   - `VIDEO_OUTPUT_DIR=/app/output/videos`
   - `SECRET_KEY=<uma-chave-aleatória>`
   - `RCLONE_CONF_BASE64=<coloque o base64 do seu rclone.conf>`
5. Primeiro deploy: o serviço sobe e roda `python main.py` (APScheduler inicia junto).

### Como gerar o `RCLONE_CONF_BASE64`
- Na sua máquina local onde o rclone está configurado:
  ```bash
  cat ~/.config/rclone/rclone.conf | base64 -w0
  ```
  Copie o output e cole na env `RCLONE_CONF_BASE64` no Render.

### Persistência
- Render Free pode hibernar. O app reativa quando acessado. O APScheduler retoma e mantém a agenda, mas execuções durante hibernação não ocorrem. Para 24/7, use um plano pago ou um VPS.

---

## Opção B — Railway (com Docker)
1. `railway init` no diretório do projeto (ou conecte via painel).
2. Deploy do Dockerfile padrão.
3. Defina as envs iguais às do Render (acima).
4. Para persistência de arquivos:
   - Crie um "Volume" no Railway e monte-o em `/app/output`.
   - Ajuste `VIDEO_OUTPUT_DIR=/app/output/videos`.
5. O APScheduler manterá os jobs em execução enquanto o serviço estiver online.

---

## Teste pós-deploy (do celular)
- `GET https://<SEU_HOST>/health`
- `GET https://<SEU_HOST>/api/system/dashboard`
- `GET https://<SEU_HOST>/api/generate-daily-content?count=2&platform=tiktok`
- `GET https://<SEU_HOST>/api/download/videos`
- `POST https://<SEU_HOST>/api/upload/google-drive` body: `{"filename":"video_tiktok_XXXX.mp4"}`

## Fluxo mobile diário
1. Abra `/api/download/videos` no navegador do celular e baixe os MP4.
2. Publique no TikTok/YouTube nos horários sugeridos (ou conforme o plano).
3. (Opcional) Chame `/api/generate-daily-content` se quiser adiantar conteúdo.
4. (Opcional) Envie para o Drive com o endpoint de upload para backup/organização.

---

## Notas
- Se você quiser 24/7 sem hibernação no free, recomendo um VPS barato e usar `docker run -d --restart=always`.
- O projeto já instala `ffmpeg` no container, pronto para evoluir para render real.
- Fuso horário do scheduler configurável pela env `TZ` (default: America/Sao_Paulo).
